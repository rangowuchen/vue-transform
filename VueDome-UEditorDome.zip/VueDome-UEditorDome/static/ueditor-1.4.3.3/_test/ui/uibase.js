/**
 * Created by JetBrains PhpStorm.
 * User: dongyancen
 * Date: 12-4-12
 * Time: 下午4:46
 * To change this template use File | Settings | File Templates.
 */
module( 'ui.uibase' );
test( '', function() {
    equal('','','');
} );