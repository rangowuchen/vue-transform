/**
 * Created by JetBrains PhpStorm.
 * User: Jinqn
 * Date: 13-10-29
 * Time: 下午5:14
 * To change this template use File | Settings | File Templates.
 */
module('plugins.autoupload');

test('拖放图片上传',function(){
    equal('','');
});

test('粘贴QQ截图',function(){
    equal('','');
});
